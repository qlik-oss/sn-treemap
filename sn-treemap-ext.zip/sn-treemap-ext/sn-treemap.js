define(['./dist/sn-treemap'], (supernova) => supernova);
